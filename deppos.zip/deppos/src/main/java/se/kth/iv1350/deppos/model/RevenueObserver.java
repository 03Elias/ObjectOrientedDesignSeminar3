package se.kth.iv1350.deppos.model;

public interface RevenueObserver {
    void update(double totalAmountOfMoney);
}